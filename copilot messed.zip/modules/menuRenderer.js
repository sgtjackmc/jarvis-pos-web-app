export function renderMenuItems(menuItems, category = 'All Items') {
    const menuGrid = document.querySelector('.menu-grid');
    menuGrid.innerHTML = '';
    
    const filteredItems = category === 'All Items' 
        ? menuItems 
        : menuItems.filter(item => item.category === category);

    filteredItems.forEach(createAndAppendMenuItem);
}

function createAndAppendMenuItem(item) {
    const menuGrid = document.querySelector('.menu-grid');
    const menuItem = document.createElement('div');
    menuItem.className = 'menu-item';
    menuItem.dataset.id = item.id;

    const content = document.createElement('div');
    content.className = 'menu-item-content';

    // Header section
    const header = createHeader(item);
    
    // Description section
    const desc = createDescription(item);
    
    // Options section
    const options = createOptions(item);
    
    // Controls section
    const controls = createControls();

    content.append(header, desc, options, controls);
    menuItem.appendChild(content);
    menuGrid.appendChild(menuItem);

    // Initialize controls after DOM insertion
    initializeControls(menuItem, item);
}

function createHeader(item) {
    const header = document.createElement('div');
    header.className = 'menu-item-header';
    header.innerHTML = `
        <h3 class="menu-item-name">${item.name}</h3>
        <div class="menu-item-price">฿${parseFloat(item.base_price || 0).toFixed(2)}</div>
    `;
    return header;
}

function createDescription(item) {
    const desc = document.createElement('div');
    desc.className = 'menu-item-desc';
    desc.textContent = item.description || '';
    return desc;
}

function createOptions(item) {
    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'menu-item-options';

    if (item.option_groups?.length > 0) {
        item.option_groups.forEach(group => {
            const fieldset = document.createElement('fieldset');
            fieldset.className = 'option-group';
            
            const legend = document.createElement('legend');
            legend.className = 'option-group-title';
            legend.textContent = group.name;

            const optionsDiv = document.createElement('div');
            optionsDiv.className = 'option-group-options';

            group.options.forEach(opt => {
                const label = createOptionLabel(item, group, opt);
                optionsDiv.appendChild(label);
            });

            fieldset.append(legend, optionsDiv);
            optionsContainer.appendChild(fieldset);
        });
    }

    return optionsContainer;
}

function createOptionLabel(item, group, option) {
    const label = document.createElement('label');
    label.className = 'option-label';

    const input = document.createElement('input');
    input.type = group.type === 'single' ? 'radio' : 'checkbox';
    input.name = `${item.id}-${group.name.replace(/\s+/g, '-')}`;
    input.className = 'option-input';
    input.dataset.price = option.price;
    input.dataset.name = option.name;
    input.dataset.group = group.name;
    input.value = option.name;

    const nameSpan = document.createElement('span');
    nameSpan.className = 'option-name';
    nameSpan.textContent = option.name;

    const priceSpan = document.createElement('span');
    priceSpan.className = 'option-price';
    priceSpan.textContent = option.price > 0 ? `+฿${option.price}` : '';

    label.append(input, nameSpan, priceSpan);
    return label;
}

function createControls() {
    const controls = document.createElement('div');
    controls.className = 'menu-item-action';
    controls.innerHTML = `
        <div class="quantity-control">
            <button type="button" class="quantity-btn minus-btn" disabled>-</button>
            <span class="quantity-value">0</span>
            <button type="button" class="quantity-btn plus-btn">+</button>
        </div>
        <button type="button" class="add-to-order-btn" disabled>Add to Order</button>
    `;
    return controls;
}

function initializeControls(menuItem, itemData) {
    const state = {
        quantity: 0,
        basePrice: parseFloat(itemData.base_price || 0),
        selectedOptions: new Set()
    };

    const controls = {
        quantityValue: menuItem.querySelector('.quantity-value'),
        minusBtn: menuItem.querySelector('.minus-btn'),
        plusBtn: menuItem.querySelector('.plus-btn'),
        addToOrderBtn: menuItem.querySelector('.add-to-order-btn'),
        options: menuItem.querySelectorAll('.option-input')
    };

    function updateControlState() {
        controls.minusBtn.disabled = state.quantity === 0;
        controls.addToOrderBtn.disabled = state.quantity === 0 || 
            (itemData.option_groups?.length > 0 && state.selectedOptions.size === 0);
        
        // Update displayed quantity
        controls.quantityValue.textContent = state.quantity;
    }

    // Quantity controls
    controls.minusBtn.addEventListener('click', () => {
        if (state.quantity > 0) {
            state.quantity--;
            updateControlState();
        }
    });

    controls.plusBtn.addEventListener('click', () => {
        state.quantity++;
        updateControlState();
    });

    // Option selection
    controls.options.forEach(option => {
        option.addEventListener('change', (e) => {
            if (e.target.checked) {
                state.selectedOptions.add(e.target.value);
            } else {
                state.selectedOptions.delete(e.target.value);
            }
            updateControlState();
        });
    });

    // Add to order
    controls.addToOrderBtn.addEventListener('click', () => {
        const selectedOptions = Array.from(controls.options)
            .filter(opt => opt.checked)
            .map(opt => ({
                name: opt.dataset.name,
                price: parseFloat(opt.dataset.price),
                group: opt.dataset.group
            }));

        const orderItem = {
            id: itemData.id,
            name: itemData.name,
            basePrice: state.basePrice,
            quantity: state.quantity,
            options: selectedOptions,
            totalPrice: calculateTotal(state.basePrice, state.quantity, selectedOptions)
        };

        // Dispatch order event
        menuItem.dispatchEvent(new CustomEvent('addToOrder', {
            bubbles: true,
            detail: orderItem
        }));

        // Reset state
        state.quantity = 0;
        state.selectedOptions.clear();
        controls.options.forEach(opt => opt.checked = false);
        updateControlState();
    });
}

function calculateTotal(basePrice, quantity, options) {
    const optionsTotal = options.reduce((sum, opt) => sum + opt.price, 0);
    return (basePrice + optionsTotal) * quantity;
}
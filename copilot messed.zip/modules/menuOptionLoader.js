export async function loadMenuData(sheetId, apiKey, menuSheet) {
    try {
        const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${menuSheet}?key=${apiKey}`);
        if (!res.ok) throw new Error(`Failed to fetch menu data: ${res.statusText}`);
        const data = await res.json();

        const { optionGroups, allOptions } = await loadOptionData(sheetId, apiKey);
        const menuItems = processMenuData(data.values, optionGroups, allOptions);
        return menuItems;
    } catch (error) {
        console.error('Error loading menu data:', error);
        return loadSampleMenuData();
    }
}

export async function loadOptionData(sheetId, apiKey) {
    try {
        const [groupRes, optionRes] = await Promise.all([
            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Option_Groups?key=${apiKey}`),
            fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Options?key=${apiKey}`)
        ]);

        if (!groupRes.ok || !optionRes.ok) {
            throw new Error('Failed to fetch option data');
        }

        const groupJson = await groupRes.json();
        const optionJson = await optionRes.json();

        // Create a map for options by group_id
        const optionsByGroup = new Map();
        
        // Skip header row and process options
        optionJson.values.slice(1).forEach(row => {
            const option = {
                option_id: row[0]?.trim(),
                group_id: row[1]?.trim(), // Changed from row[0] to row[1]
                name: row[2]?.trim(),     // Changed from row[1] to row[2]
                price: parseFloat(row[3]) || 0  // Changed from row[2] to row[3]
            };

            if (!optionsByGroup.has(option.group_id)) {
                optionsByGroup.set(option.group_id, []);
            }
            optionsByGroup.get(option.group_id).push(option);
            console.log(`Added option ${option.name} to group ${option.group_id}`);
        });

        // Process option groups
        const optionGroups = groupJson.values.slice(1).map(row => {
            const group = {
                group_id: row[0]?.trim(),
                menu_ids: row[1]?.split(',').map(id => id.trim()),
                name: row[2]?.trim(),
                type: row[3]?.trim() || 'multi',
                options: optionsByGroup.get(row[0]?.trim()) || [] // Get options for this group
            };

            console.log(`Group ${group.group_id} has ${group.options.length} options:`, 
                JSON.stringify(group.options, null, 2));

            return group;
        });

        return {
            optionGroups,
            allOptions: Array.from(optionsByGroup.values()).flat()
        };
    } catch (error) {
        console.error('Error loading option data:', error);
        return { optionGroups: [], allOptions: [] };
    }
}

export function processMenuData(values, optionGroups, allOptions) {
    const headers = values[0];
    const rows = values.slice(1);

    return rows.map(row => {
        const item = {};
        headers.forEach((key, index) => {
            item[key.toLowerCase().replace(/\s/g, '_')] = row[index] || '';
        });

        // Find groups that match this menu item
        const matchedGroups = optionGroups.filter(group => 
            group.menu_ids.includes(item.id)
        );

        console.log(`Menu item ${item.id} matched with ${matchedGroups.length} groups`);

        // Map the matched groups with their options
        item.option_groups = matchedGroups.map(group => ({
            name: group.name,
            type: group.type,
            options: group.options.map(opt => ({
                name: opt.name,
                price: opt.price
            }))
        }));

        return item;
    });
}

export function loadSampleMenuData() {
    return [
        {
            id: '1',
            name: 'Classic JAX Burger',
            base_price: 10.99, // Changed to Number
            description: 'Beef patty, lettuce, tomato, pickles, onions, and special JAX sauce.',
            category: 'Burgers',
            image_url: '/api/placeholder/400/320',
            option_groups: []
        },
        {
            id: '2',
            name: 'French Fries',
            base_price: 4.99, // Changed to Number
            description: 'Crispy golden fries with sea salt.',
            category: 'Sides',
            image_url: '/api/placeholder/400/320',
            option_groups: []
        }
    ];
}


